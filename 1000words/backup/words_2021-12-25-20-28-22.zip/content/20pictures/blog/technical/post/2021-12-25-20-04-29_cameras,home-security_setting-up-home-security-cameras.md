<!--t Setting up Home Security Cameras t-->
<!--d I’ve been asked on several occasions, for advice on setting up a camera home security system. With this goal in mind, I have decided to document d-->
<!--tag Cameras,Home Security tag-->

I’ve been asked on several occasions, for advice on setting up a camera home security system. With this goal in mind, I have decided to document the process in a user-friendly manner. My research & observations are not sponsored & may be subject to changes, as I discover more about the abilities & requirements of the many options.

As a professional photographer, whose experiences bridge two centuries, I witnessed the genesis of digital photography, the explosion of image content & the advancement of camera. All this grew hand-in-hand with a similar exponential growth of the personal computer & available software.

Today, we have the opportunity to install our own highly advanced home security camera systems, capable of meeting a variety of needs, at an affordable price. I will discuss the basic requirements in the form of a starter guide, this is not definitive or expert, & will allow your own interpretation & future updates.

All home security camera systems require a number of online accounts, so to start with, we will look at passwords & their secure storage…


![Neos SmartCam][1]


  [1]: http://johnwalton.photography/words/content/images/20211225200358-u_10196900_400.jpg